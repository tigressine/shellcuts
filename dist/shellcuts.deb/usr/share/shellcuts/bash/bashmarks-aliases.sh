# Part of Shellcuts by Tgsachse.

# Aliases to emulate the original huyng/bashmarks syntax.
alias s="sc -n"
alias g="sc"
alias p="sc -p"
alias d="sc -d"
alias l="sc -l"
