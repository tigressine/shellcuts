Bookmarks for your shell.


