Shortcuts for your shell.


