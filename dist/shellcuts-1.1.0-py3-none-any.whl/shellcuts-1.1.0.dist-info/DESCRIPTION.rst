This is the description file for PyPI


