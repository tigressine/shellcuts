#!/usr/bin/env python3

F_SOURCE = "/usr/local/bin/shellcuts.sh"
